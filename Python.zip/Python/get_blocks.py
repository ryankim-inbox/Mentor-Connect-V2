"""
Handles block/report-related DB checks.

If student A blocked mentor B, mentor B should not appear on A
If mentor B blocked student A, mentor A should not appear on B

Any blocked relationship should prevent them from being connected as mentor-mentee

each report, we give warning

3 reports, give serious warning

5 reports, ban the user (Maybe have another DB, and add the USER data in, to prevent sign up

"""

