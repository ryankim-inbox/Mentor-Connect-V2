"""
matching algorithm

Process:
1. Receives a question_id.
2. Loads that question from PostgreSQL.
3. Loads the student who asked the question.
4. Loads all mentors.
5. Skips blocked users.
6. Calculates a matching score.
7. Returns the final result - Result should be in JSON format.
"""
