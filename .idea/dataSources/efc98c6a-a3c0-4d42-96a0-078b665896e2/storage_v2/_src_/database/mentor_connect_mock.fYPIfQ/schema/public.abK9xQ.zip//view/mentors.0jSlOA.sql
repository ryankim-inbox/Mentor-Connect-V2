create view mentors
            (mentor_id, mentor, subjects, location, available_times, languages, grade_level, teaching_style,
             district_id) as
SELECT id   AS mentor_id,
       name AS mentor,
       subjects,
       location,
       available_times,
       languages,
       grade_level,
       teaching_style,
       district_id
FROM users
WHERE role = ANY (ARRAY ['mentor'::text, 'both'::text]);

alter table mentors
    owner to rinny;

