create view v_mentor_ranks(mentor_id, mentor_name, matched_requests, avg_response_hours) as
SELECT u.id                                                                    AS mentor_id,
       u.name                                                                  AS mentor_name,
       count(r.id)::integer                                                    AS matched_requests,
       round(avg(EXTRACT(epoch FROM r.updated_at - r.created_at) / 3600.0), 1) AS avg_response_hours
FROM users u
         JOIN requests r ON r.matched_user_id = u.id AND r.status = 'matched'::text
WHERE u.role = ANY (ARRAY ['mentor'::text, 'both'::text])
GROUP BY u.id, u.name
ORDER BY (count(r.id)::integer) DESC, (round(avg(EXTRACT(epoch FROM r.updated_at - r.created_at) / 3600.0), 1));

alter table v_mentor_ranks
    owner to rinny;

