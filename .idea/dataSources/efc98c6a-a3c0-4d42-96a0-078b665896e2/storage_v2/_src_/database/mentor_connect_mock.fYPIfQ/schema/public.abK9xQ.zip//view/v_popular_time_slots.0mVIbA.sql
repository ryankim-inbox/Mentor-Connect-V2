create view v_popular_time_slots(slot, user_count) as
SELECT slot,
       count(*)::integer AS user_count
FROM schedules
GROUP BY slot
ORDER BY (count(*)::integer) DESC, slot;

alter table v_popular_time_slots
    owner to rinny;

