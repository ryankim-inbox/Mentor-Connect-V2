create view v_response_times(request_id, author_id, matched_user_id, response_hours) as
SELECT id                                                             AS request_id,
       author_id,
       matched_user_id,
       round(EXTRACT(epoch FROM updated_at - created_at) / 3600.0, 1) AS response_hours
FROM requests r
WHERE status = 'matched'::text
ORDER BY id;

alter table v_response_times
    owner to rinny;

