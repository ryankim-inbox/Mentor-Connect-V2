create view schedules_db(schedules, user_id, created_at) as
SELECT slot AS schedules,
       user_id,
       created_at
FROM schedules;

alter table schedules_db
    owner to rinny;

