create view v_popular_subjects(tag_id, subject, request_count) as
SELECT t.id                  AS tag_id,
       t.name                AS subject,
       count(rt.id)::integer AS request_count
FROM tags t
         LEFT JOIN request_tags rt ON rt.tag_id = t.id
GROUP BY t.id, t.name
ORDER BY (count(rt.id)::integer) DESC, t.name;

alter table v_popular_subjects
    owner to rinny;

